#pragma once
#ifndef COMMON_H
#define COMMON_H
#define NS_COMMON_BEGIN namespace Util { namespace Common {
#define NS_COMMON_END } }
#define USING_COMMON using namespace Util::Common;
#endif