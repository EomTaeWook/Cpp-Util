#pragma once

#ifndef SOCKET_H
#define SOCKET_H
#define NS_SOCKET_BEGIN namespace Util { namespace Socket {
#define NS_SOCKET_END } }
#define USING_SOCKET using namespace Util::Socket;
#endif