#pragma once

#ifndef CRYPTOGRAPHY_H
#define CRYPTOGRAPHY_H
#define NS_CRYPTOGRAPHY_BEGIN namespace Util { namespace Cryptography {
#define NS_CRYPTOGRAPHY_END } }
#define USING_CRYPTOGRAPHY using namespace Util::Cryptography;
#endif