#pragma once

#ifndef MESSAGE_MSMQ_H
#define MESSAGE_MSMQ_H
#define NS_MESSAGE_MSMQ_BEGIN namespace Util { namespace Message { namespace MS { 
#define NS_MESSAGE_MSMQ_END } } }
#define USING_MESSAGE_MSMQ using namespace Util::Message::MS;
#endif