#pragma once

#ifndef EVENT_H
#define EVENT_H
#define NS_EVENT_BEGIN namespace Util { namespace Event {
#define NS_EVENT_END } }
#define USING_EVENT using namespace Util::Event;
#endif