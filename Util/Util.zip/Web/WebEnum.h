#pragma once
#include "NS.h"

NS_WEB_BEGIN

enum class Method
{
	Get,
	Post,
	Put,
	Delete,
};

NS_WEB_END