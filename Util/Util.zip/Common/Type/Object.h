#pragma once
#include "NS.h"
NS_COMMON_TYPE_BEGIN
class Object
{
public:
	Object() {}
public:
	virtual ~Object() {}
};
NS_COMMON_TYPE_END
