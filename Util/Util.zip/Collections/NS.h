#pragma once
#ifndef COLLECTIONS_H
#define COLLECTIONS_H
#define NS_COLLECTIONS_BEGIN namespace Util { namespace Collections {
#define NS_COLLECTIONS_END } }
#define USING_COLLECTIONS using namespace Util::Collections;
#endif