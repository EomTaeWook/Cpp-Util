#pragma once
#ifndef HTTP_H
#define HTTP_H
#define NS_WEB_HTTP_BEGIN namespace Util { namespace Web { namespace Http {
#define NS_WEB_HTTP_END } } } 
#define USING_WEB_HTTP using namespace Util::Web::Http;

#define NS_WEB_BEGIN namespace Util { namespace Web {
#define NS_WEB_END } }
#define USING_WEB_HTTP using namespace Util::Web::Http;
#define USING_WEB using namespace Util::Web;
#endif