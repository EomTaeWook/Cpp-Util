#pragma once
#ifndef COMMON_TYPE_H
#define COMMON_TYPE_H
#define NS_COMMON_TYPE_BEGIN namespace Util { namespace Common { namespace Type {
#define NS_COMMON_TYPE_END } } }
#define USING_COMMON_TYPE using namespace Util::Common::Type;
#endif