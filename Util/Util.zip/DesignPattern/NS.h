#pragma once

#ifndef DESIGN_PATTERN_H
#define DESIGN_PATTERN_H
#define NS_DESIGN_PATTERN_BEGIN namespace Util { namespace DesignPattern {
#define NS_DESIGN_PATTERN_END } }
#define USING_DESIGN_PATTERN using namespace Util::DesignPattern;
#endif