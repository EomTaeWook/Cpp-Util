#pragma once

#ifndef THREADING_H
#define THREADING_H
#define NS_THREADING_BEGIN namespace Util { namespace Threading {
#define NS_THREADING_END } }
#define USING_THREADING using namespace Util::Threading;
#endif